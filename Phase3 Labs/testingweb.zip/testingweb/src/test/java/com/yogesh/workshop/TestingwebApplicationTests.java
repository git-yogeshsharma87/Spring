package com.yogesh.workshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
